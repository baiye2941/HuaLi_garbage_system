from .huali_garbage_core import *

__doc__ = huali_garbage_core.__doc__
if hasattr(huali_garbage_core, "__all__"):
    __all__ = huali_garbage_core.__all__